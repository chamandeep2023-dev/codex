PARTIAL DELIVERY — AI-GENERATED DRAFTS

This archive contains 9 language drafts, 3 text-free bases (Creatives 3, 4, 5), and the status table for all 21 variants listed in the request.

The supplied strings were added using image generation after existing advertisement lettering was removed. Text regions were enlarged and visually checked against the supplied strings. The Creative 5 ai label is retained.

These are drafts: generative editing changed original visual details, typography/placement and pixel dimensions. They do not meet the requirement that every non-text pixel and original dimensions remain unchanged.

Creative 3 outputs: 1055 x 1491 (original: 843 x 1192).
Creative 4 outputs: 1254 x 1254 (original: 613 x 613).
Creative 5 outputs: 1254 x 1254 (original: 1080 x 1080).

Creative 5 text-removal retry succeeded. Its Malayalam, Tamil and Kannada language drafts were generated and reviewed. Bengali text-addition was rejected by the image tool safety filter.

Creative 1 and 7 originals were reattached, but their text-removal retries were again rejected by the image tool safety filter. Creative 6's reattached original and subsequent retry were also rejected. No language files or text-free bases were produced for Creatives 1, 6 or 7. Missing variants are listed as skipped in status.csv. The unrelated Hindi image was ignored.
